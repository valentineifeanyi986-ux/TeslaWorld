-- TeslaWorld starter schema. Run in Supabase SQL Editor.
-- IMPORTANT: never expose the service_role key in browser code.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  request_type text not null check (request_type in ('purchase','reservation')),
  vehicle_ids text[] not null default '{}',
  country text not null,
  city text not null,
  customer_note text,
  status text not null default 'submitted'
    check (status in ('submitted','contacted','under_review','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.payment_records (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text not null,
  provider_reference text unique,
  amount numeric(12,2) not null check (amount >= 0),
  currency text not null default 'USD' check (currency = 'USD'),
  status text not null default 'pending' check (status in ('pending','succeeded','failed','refunded')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.orders enable row level security;
alter table public.payment_records enable row level security;

-- Helper function avoids recursive profile policies.
create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

drop policy if exists "profile read own or admin" on public.profiles;
create policy "profile read own or admin" on public.profiles
for select to authenticated using (id = auth.uid() or public.is_admin());

drop policy if exists "profile update own" on public.profiles;
create policy "profile update own" on public.profiles
for update to authenticated using (id = auth.uid()) with check (id = auth.uid() and role = 'customer');

drop policy if exists "orders insert own" on public.orders;
create policy "orders insert own" on public.orders
for insert to authenticated with check (user_id = auth.uid());

drop policy if exists "orders read own or admin" on public.orders;
create policy "orders read own or admin" on public.orders
for select to authenticated using (user_id = auth.uid() or public.is_admin());

drop policy if exists "orders update admin only" on public.orders;
create policy "orders update admin only" on public.orders
for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "payments read own or admin" on public.payment_records;
create policy "payments read own or admin" on public.payment_records
for select to authenticated using (user_id = auth.uid() or public.is_admin());

-- Payment records must be written by a trusted server/webhook, not the browser.
-- No client insert/update policy is intentionally provided.

-- Create a profile automatically when a user signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- After creating your own account, promote it to admin from the SQL editor:
-- update public.profiles set role = 'admin' where id = 'YOUR_AUTH_USER_UUID';
-- Do this only for your own verified account. Never let users self-assign admin.

# TeslaWorld setup guide

This is a responsive starter project for an independent Tesla vehicle information and enquiry showroom.

## Included
- Registration and sign-in using Supabase Auth.
- Mandatory sign-in before browsing.
- Fixed Tesla model-family catalogue (no product management or product upload).
- Vehicle detail pages, search and category filter.
- Shortlist/cart and purchase or reservation enquiry submission.
- Customer activity page.
- Admin dashboard sections: overview, orders/reservations, customers, reviews placeholder, image-assets guidance, website settings and security.
- Supabase SQL schema with row-level security.

## Important launch limitations
This project does **not** take payments and does not confirm a vehicle sale or reservation. The checkout submits an enquiry only. A secure payment integration requires a server-side payment session and verified payment-provider webhook (for example, Stripe), plus legally valid seller, inventory, refund and delivery arrangements. Do not collect card details in this website.

The catalogue is a fixed set of model-family information. Price fields intentionally say "verify current regional price"; no live Tesla pricing or inventory feed is connected. Specifications and image URLs are illustrative reference content and must be checked against current official regional sources before publication. Some models or trims may not be available in every country. Replace remote images with licensed images you are entitled to use.

TeslaWorld is an independent project and is not affiliated with Tesla, Inc. Do not use Tesla trademarks or branding in a way that suggests official endorsement.

## 1. Create a Supabase project
1. Create a project in Supabase.
2. Open **SQL Editor**.
3. Paste and run `supabase/schema.sql`.
4. Open **Project Settings → API** and copy the Project URL and Publishable key (or legacy anon public key).
5. Put those values in `config.js`. Never use the `service_role` or secret key in `config.js`.

## 2. Enable authentication
1. In Supabase, open **Authentication → Providers** and enable Email.
2. Configure your site URL and redirect URLs in Authentication URL settings.
3. For production, keep email confirmation enabled and configure SMTP so confirmation emails can be delivered.

## 3. Create your administrator
1. Register your own account through the website.
2. In Supabase, open **Authentication → Users**, find your account and copy its user UUID.
3. In SQL Editor run this command, replacing the placeholder with your own UUID:

   `update public.profiles set role = 'admin' where id = 'YOUR_AUTH_USER_UUID';`

4. Sign out and sign back in. Use the Admin button in the footer. Only accounts with the admin role can access admin data.

Do not share your admin password or give customers the admin role.

## 4. Run the website
For a quick local test, open `index.html` in a modern browser after setting `config.js`. For best results, use a local static server or deploy the folder to Vercel. Supabase Auth redirect URLs must match the address you use.

## 5. Before accepting real orders or money
- Establish that you are authorised and able to source and sell the vehicles offered.
- Confirm each vehicle's actual VIN, condition, title, model year, trim, mileage and availability.
- Confirm destination-country import, homologation, tax, customs and registration rules.
- Publish accurate seller identity, contact details, terms, privacy policy, cancellation/refund policy and delivery terms.
- Confirm the final price in USD and state what is and is not included.
- Implement a secure server-side payment flow and webhook verification. Never trust a browser message as proof of payment.
- Use a payment provider that supports your business country, settlement currency and customer destination countries.

## Project files
- `index.html` — page structure
- `styles.css` — responsive futuristic design
- `app.js` — catalogue, navigation, auth, enquiries and admin interface
- `config.js` — public Supabase connection settings
- `supabase/schema.sql` — database tables, trigger and security policies

## Catalogue maintenance
The catalogue is intentionally fixed. Vehicle text and image URLs are defined in the `VEHICLES` array near the top of `app.js`. Updating this source file is a controlled project release, not an admin product-management feature.


## Vehicle photo gallery and 360-degree viewer

The vehicle detail page now includes six labelled photo positions for each model: front, rear, left side, right side, dashboard & steering, and cabin interior. It also includes drag, arrow and auto-rotate controls. The controls cycle through the four exterior-angle images; a smooth continuous 360-degree spin requires a genuine multi-frame 360 photo sequence.

The rebuilt project currently provides clearly labelled image placeholders rather than inventing or reusing unrelated photos as if they were the exact vehicle views. To populate the gallery, add six licensed/authorized, model-specific images per vehicle and set the matching `gallery` paths in that vehicle's entry near the top of `app.js`. Example keys: `front`, `rear`, `left`, `right`, `cockpit`, and `interior`. Use paths such as `assets/vehicles/model-s/front.jpg`. Repeat for `model-3`, `model-x`, `model-y`, `cybertruck`, and `roadster`.

For commercial use, obtain image rights or written permission. Tesla's public media gallery states that its media assets are restricted to qualifying media/editorial use and are not permitted for advertising or commercial promotion without prior written consent: https://www.tesla.com/tesla-gallery.


## Tesla branding and vehicle information
TeslaWorld is an independent showcase, not an official Tesla website. Tesla names, marks and product imagery are owned by Tesla, Inc. Obtain appropriate permission before commercial use. The Roadster listing describes the October 2026 reveal and should be treated as preliminary manufacturer information; confirm all specifications, road approval, pricing, production and market availability directly with Tesla.

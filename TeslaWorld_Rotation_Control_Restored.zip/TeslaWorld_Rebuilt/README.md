# TeslaWorld

Responsive Tesla vehicle information and enquiry website starter.

## Quick start
1. Open `config.js` and enter your Supabase Project URL and Publishable key.
2. In your Supabase project, run `supabase/schema.sql` in SQL Editor.
3. Follow `SETUP.md` for Authentication settings, admin setup and Vercel deployment.
4. Upload/replace the project files in your GitHub repository and let Vercel deploy.

**Important:** `config.js` in this ZIP intentionally contains placeholders. You must enter your own project URL and publishable key before customer sign-in can work. Never put a Supabase `service_role` or secret key in browser code, and do not send your keys in chat.

TeslaWorld is an independent vehicle information and enquiry project, not affiliated with Tesla, Inc. The site submits enquiries only; it does not process payments or confirm vehicle inventory or reservations. Review `SETUP.md` before launch.


Branding and catalogue note: TeslaWorld uses a Tesla-style T mark and Tesla vehicle names for an independent informational/enquiry showcase. It is not affiliated with Tesla, Inc. The redesigned Roadster entry reflects Tesla's October 2026 reveal; specifications, road approval, pricing, production timing and regional availability must be confirmed directly with Tesla. Obtain permission for commercial use of Tesla trademarks and images before public launch.
